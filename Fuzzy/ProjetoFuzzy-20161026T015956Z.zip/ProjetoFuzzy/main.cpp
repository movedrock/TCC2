/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   main.cpp
 * Author: Marcelle
 *
 * Created on 23 de Outubro de 2016, 22:50
 */

#include <cstdlib>

using namespace std;

//triangular
typedef struct mf_s{
    
    char* nome; 
    int pontoA;
    int pontoB;
    
    int pertinencia;
};

//IF a AND b THEN c
typedef struct rule_s{
    
    mf_s* a_t;
    mf_s* b_t;
    mf_s* c_t;
};


/*
 * 
 */
int main(int argc, char** argv) {

    
    //teste1
    
    return 0;
}

